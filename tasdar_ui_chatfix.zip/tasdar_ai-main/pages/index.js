export default function Home() {
  return (
    <main>
      <h1>Selamat Datang ke TAS.DAR</h1>
      <p>UI ini sedang dibina semula dalam Next.js.</p>
      <a href="/chat">Mula Berbual</a>
    </main>
  );
}